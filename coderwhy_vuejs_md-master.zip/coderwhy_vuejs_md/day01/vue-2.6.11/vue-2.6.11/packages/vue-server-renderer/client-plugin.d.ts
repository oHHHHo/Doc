import { WebpackPlugin } from './types/plugin';
declare const Plugin: WebpackPlugin;
export = Plugin;
